const fs = require('fs')
const path = require('path')
const required = ['tsconfig.json', 'next-env.d.ts']
let missing = []
for (const f of required) {
  if (!fs.existsSync(path.join(process.cwd(), f))) missing.push(f)
}
if (missing.length > 0) {
  console.error('TypeScript setup check failed. Missing files: ' + missing.join(', '))
  process.exit(1)
}
console.log('TypeScript setup check passed. All required files present.')
process.exit(0)
