module.exports = {
  content: ["./pages/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        'bst-blue': '#0B5FFF',
        'bst-gold': '#D4AF37',
        'bst-navy': '#05204A'
      }
    }
  },
  plugins: []
}
