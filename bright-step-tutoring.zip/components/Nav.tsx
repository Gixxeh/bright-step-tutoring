import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'
import React from 'react'

export default function Nav(): JSX.Element {
  const { data: session } = useSession()
  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center gap-4">
            <Link href="/">
              <a className="flex items-center gap-2">
                <img src="/logo.png" alt="Bright Step Tutoring" className="w-28 object-contain" />
              </a>
            </Link>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/services"><a>Services</a></Link>
            <Link href="/pricing"><a>Pricing</a></Link>
            <Link href="/dashboard"><a>Dashboard</a></Link>
            {session ? (
              <button onClick={() => signOut()} className="px-3 py-1 rounded-md border">Sign out</button>
            ) : (
              <Link href="/login"><a className="px-3 py-1 rounded-md bg-bst-blue text-white">Login</a></Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  )
}
