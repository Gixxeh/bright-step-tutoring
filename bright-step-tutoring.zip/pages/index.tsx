import Nav from '../components/Nav'
import Link from 'next/link'
import type { NextPage } from 'next'
import React from 'react'

const Home: NextPage = () => {
  return (
    <div>
      <Nav />
      <header className="py-20">
        <div className="max-w-5xl mx-auto text-center px-4">
          <h1 className="text-4xl font-extrabold text-bst-navy">Bright Step Tutoring</h1>
          <p className="mt-4 text-lg text-gray-600">Practical tips, structured lessons and regular assessments to help students excel in WAEC, NECO and UTME.</p>
          <div className="mt-8 flex justify-center gap-4">
            <Link href="/pricing"><a className="px-6 py-3 rounded-md bg-bst-gold text-white font-semibold">Get Started</a></Link>
            <Link href="/about"><a className="px-6 py-3 rounded-md border">Learn More</a></Link>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 pb-20">
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 bg-white rounded shadow">
            <h3 className="font-semibold">Experienced Tutors</h3>
            <p className="mt-2 text-sm text-gray-600">Qualified tutors for Primary to JSS levels.</p>
          </div>
          <div className="p-6 bg-white rounded shadow">
            <h3 className="font-semibold">Interactive Lessons</h3>
            <p className="mt-2 text-sm text-gray-600">Monthly live classes, recorded sessions and assessments.</p>
          </div>
          <div className="p-6 bg-white rounded shadow">
            <h3 className="font-semibold">Secure Payments</h3>
            <p className="mt-2 text-sm text-gray-600">Paystack-powered payments and subscriptions.</p>
          </div>
        </section>
      </main>
    </div>
  )
}

export default Home
