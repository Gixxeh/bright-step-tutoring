import Nav from '../components/Nav'
import type { NextPage } from 'next'
import React from 'react'

const Pricing: NextPage = () => {
  return (
    <div>
      <Nav />
      <div className="max-w-4xl mx-auto p-6">
        <h2 className="text-2xl font-semibold">Pricing</h2>
        <p className="mt-2">Subscription: ₦25,000 / month</p>
        <div className="mt-6">
          <form action="/api/paystack/init-checkout" method="POST">
            <input type="hidden" name="amount" value="2500000" />
            <label className="block">Email</label>
            <input name="email" className="border p-2 rounded w-full max-w-sm mb-4" defaultValue="student@brightstep.com" />
            <button type="submit" className="px-4 py-2 rounded bg-bst-blue text-white">Subscribe (Test)</button>
          </form>
        </div>
      </div>
    </div>
  )
}

export default Pricing
