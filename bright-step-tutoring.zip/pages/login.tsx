import { getCsrfToken } from 'next-auth/react'
import { useState } from 'react'
import Nav from '../components/Nav'
import type { GetServerSideProps } from 'next'
import React from 'react'

type Props = { csrfToken: string | null }

export default function Login({ csrfToken }: Props) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  return (
    <div>
      <Nav />
      <div className="max-w-md mx-auto p-6 mt-12 bg-white rounded shadow">
        <h2 className="text-2xl font-semibold">Login</h2>
        <form method="post" action="/api/auth/callback/credentials" className="mt-4 space-y-4">
          <input name="csrfToken" type="hidden" defaultValue={csrfToken ?? ''} />
          <div>
            <label className="block text-sm">Email</label>
            <input name="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full border p-2 rounded" />
          </div>
          <div>
            <label className="block text-sm">Password</label>
            <input name="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full border p-2 rounded" />
          </div>
          <div>
            <button type="submit" className="px-4 py-2 bg-bst-blue text-white rounded-md">Sign in</button>
          </div>
        </form>
      </div>
    </div>
  )
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const token = await getCsrfToken(context)
  return { props: { csrfToken: token } }
}
