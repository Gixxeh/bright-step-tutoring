import NextAuth from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import type { NextAuthOptions } from 'next-auth'
import { compareSync } from 'bcryptjs'
import seedUsers from '../../../seed/users.json'

const users = seedUsers as any[]

const options: Partial<NextAuthOptions> = {
  session: { strategy: 'jwt' },
  providers: [
    CredentialsProvider({
      name: 'Credentials',
      credentials: {
        email: { label: 'Email', type: 'text' },
        password: { label: 'Password', type: 'password' }
      },
      async authorize(credentials: any) {
        if (!credentials?.email) return null
        const user = users.find(u => u.email === credentials.email)
        if (!user) return null
        // passwords in seed are plain text for demo ('Admin123!' etc.)
        if (credentials.password !== user.password) return null
        return { id: user.id, email: user.email, role: user.role }
      }
    })
  ],
  callbacks: {
    async jwt({ token, user }: any) {
      if (user) token.role = user.role
      return token
    },
    async session({ session, token }: any) {
      session.user = session.user || {}
      session.user.role = token.role
      return session
    }
  },
  secret: process.env.NEXTAUTH_SECRET || 'dev_secret'
}

export default NextAuth(options as any)
