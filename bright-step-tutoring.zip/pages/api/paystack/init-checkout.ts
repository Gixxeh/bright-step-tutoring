import axios from 'axios'
import type { NextApiRequest, NextApiResponse } from 'next'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).end()
  try {
    const { email, amount } = req.body
    const response = await axios.post('https://api.paystack.co/transaction/initialize', {
      email,
      amount // in kobo
    }, {
      headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}` }
    })
    return res.status(200).json(response.data)
  } catch (err: any) {
    return res.status(500).json({ error: err.message })
  }
}
