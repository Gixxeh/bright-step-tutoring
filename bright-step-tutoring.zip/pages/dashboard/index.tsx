import Nav from '../../components/Nav'
import { getSession } from 'next-auth/react'
import type { GetServerSideProps, NextPage } from 'next'
import React from 'react'

type Props = { user: { email?: string } }

const Dashboard: NextPage<Props> = ({ user }) => {
  return (
    <div>
      <Nav />
      <div className="max-w-6xl mx-auto p-6">
        <h1 className="text-2xl font-semibold">Dashboard</h1>
        <p className="mt-2">Welcome, {user?.email}</p>

        <section className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-white rounded shadow">Payments</div>
          <div className="p-4 bg-white rounded shadow">Students</div>
          <div className="p-4 bg-white rounded shadow">Classes</div>
        </section>
      </div>
    </div>
  )
}

export const getServerSideProps: GetServerSideProps = async (ctx) => {
  const session = await getSession(ctx as any)
  if (!session) {
    return { redirect: { destination: '/login', permanent: false } }
  }
  return { props: { user: session.user } }
}

export default Dashboard
