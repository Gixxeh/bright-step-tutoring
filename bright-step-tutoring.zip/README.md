# Bright Step Tutoring — Ready-to-deploy Starter (Demo)

This package is a ready-to-deploy Next.js + TypeScript starter for **Bright Step Tutoring**.
It includes:
- Your logo (public/logo.png)
- Multi-role demo users (Admin, Tutor, Student)
- Login and dashboard (basic demo, credentials-based)
- Paystack transaction initialization route (test mode)
- Tailwind + blue/gold theme
- README with step-by-step deployment guide and screenshots

---

## What's included

**Demo accounts**
- Admin: admin@brightstep.com / Admin123!
- Tutor: tutor@brightstep.com / Tutor123!
- Student: student@brightstep.com / Student123!

**Files of note**
- `pages/` — Next.js pages (index, login, dashboard, pricing)
- `components/Nav.tsx` — navbar with your logo wired in
- `pages/api/auth/[...nextauth].ts` — credentials auth using the seeded users file (for demo only)
- `pages/api/paystack/init-checkout.ts` — initializes transaction with Paystack (server-side)
- `seed/users.json` — demo users used by the credentials auth provider
- `.env.example` — environment variables to set before deploying

---

## Quick local test (if you are comfortable with a little technical work)

> Note: If you're not comfortable running commands locally, skip to the **Deploy to Vercel** section below. The Vercel flow is UI-driven and easier.

1. Copy the project folder to your machine.
2. `npm install`
3. Copy `.env.example` to `.env` and set `NEXTAUTH_SECRET` and `PAYSTACK_SECRET_KEY` (use your Paystack test secret key).
4. `npm run dev`
5. Open `http://localhost:3000` and try logging in with the demo accounts.

---

## Deploy to Vercel (recommended for non-programmers — GUI driven)

1. Create a **new GitHub repo** (name suggestion: `bright-step-tutoring`).
2. Upload the contents of this project (drag-and-drop the folder in the GitHub web UI).
   - Screenshot: (example) `./screenshots/github_upload.png`
3. Sign in to **Vercel** (https://vercel.com) with your GitHub account, click **New Project** → Import Git Repository → select the repo.
   - Screenshot: (example) `./screenshots/vercel_import.png`
4. In the Vercel project settings, add the environment variables (copy from `.env.example`):
   - `NEXTAUTH_SECRET` = a secure random string (you can generate one with an online tool)
   - `PAYSTACK_SECRET_KEY` = your Paystack test secret key (e.g., `sk_test_...`)
   - `NEXT_PUBLIC_PAYSTACK_PLAN_ID` = (optional) plan id if you create one in Paystack
5. Deploy. Vercel will build and publish the site. Open the provided URL and log in with the demo accounts above.

---

## Paystack testing notes

- This starter calls Paystack's `transaction/initialize` endpoint server-side and returns the authorization URL to the client (in a real app you'd redirect a user to the authorization URL).
- Use the Paystack test secret key (`sk_test_...`) in Vercel as an environment variable for sandbox testing.
- For subscriptions, create a plan in Paystack dashboard or via the API and copy the plan id into `NEXT_PUBLIC_PAYSTACK_PLAN_ID`.

---

## Screenshots and help
I included placeholder screenshot paths under `./screenshots/`. If you'd like, I can generate actual screenshots for each step and place them there before you upload to GitHub (I can do that next).

---

## Security & next steps
- This demo uses seeded users in a JSON file for convenience. **Do not** use this approach in production.
- For production-ready deployment: use a proper database (Postgres via Supabase/Railway), Prisma ORM, hashed passwords, and Paystack webhooks to track subscription status.
- I can also connect the repo to your GitHub and deploy to Vercel for you if you prefer — you'll need to authorize the connection.

---

If you're ready, download the zip below, upload to GitHub, and tell me when you're at the Vercel environment variable screen — I'll give you the exact values to paste.
